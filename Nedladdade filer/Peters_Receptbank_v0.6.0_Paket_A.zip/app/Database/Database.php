<?php
// PDO-klass kommer att implementeras här.
