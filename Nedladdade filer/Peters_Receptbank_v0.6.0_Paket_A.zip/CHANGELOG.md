v0.6.0 Paket A
- Paketstruktur skapad.
