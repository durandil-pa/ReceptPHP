# Peters Receptbank v0.6.0 - Paket A

Detta paket är avsett för:
- PDO-databaslager
- Router
- Autoloader
- Sessionshantering
- Basklasser

OBS: Detta är paketstrukturen för Paket A. Nästa steg är att fylla dessa filer
med den fullständiga implementationen.
