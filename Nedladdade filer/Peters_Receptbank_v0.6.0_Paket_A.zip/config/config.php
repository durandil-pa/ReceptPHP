<?php
// Konfiguration kommer att implementeras här.
