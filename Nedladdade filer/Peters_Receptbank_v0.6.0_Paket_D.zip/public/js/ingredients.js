// Dynamisk ingredienshantering implementeras senare.
