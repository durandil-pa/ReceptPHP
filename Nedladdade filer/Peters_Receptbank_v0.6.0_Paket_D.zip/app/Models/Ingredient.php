<?php
// Ingredient-modell implementeras i nästa steg.
