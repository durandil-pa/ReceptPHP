v0.6.0 Paket D
- recipe show/create/edit
- ingredient editor
