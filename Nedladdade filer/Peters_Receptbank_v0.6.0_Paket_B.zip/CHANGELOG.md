v0.6.0 Paket B
- LoginController
- Auth-klass
- User-modell
- Dashboard-vy
