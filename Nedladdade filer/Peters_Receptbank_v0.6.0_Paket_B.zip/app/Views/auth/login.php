<h2>Logga in</h2>
<form><input placeholder='Användarnamn'><br><input type='password' placeholder='Lösenord'><br><button>Logga in</button></form>