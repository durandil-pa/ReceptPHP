<?php
// Auth-hjälpklass - implementeras i nästa steg.
