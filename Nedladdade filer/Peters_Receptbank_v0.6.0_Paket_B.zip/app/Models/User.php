<?php
// User-modell - implementeras i nästa steg.
