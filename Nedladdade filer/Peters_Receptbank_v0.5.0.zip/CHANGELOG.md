v0.5.0
- Grundprojekt påbörjat.
