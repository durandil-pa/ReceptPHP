1. Skapa databasen.
2. Anpassa config/config.php.
3. Lägg projektet i webbserverns rot.
