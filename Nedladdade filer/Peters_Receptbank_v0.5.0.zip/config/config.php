<?php
define('APP_NAME','Peters Receptbank');
define('APP_VERSION','0.5.0');
