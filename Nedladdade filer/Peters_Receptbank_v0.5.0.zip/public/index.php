<?php
require_once __DIR__ . '/../bootstrap/app.php';
echo "<h1>Peters Receptbank v0.5.0</h1>";
