<!doctype html>
<html><head><title>Recept</title></head>
<body>
<h2>Receptlista</h2>
<table border='1' cellpadding='6'>
<tr><th>Namn</th><th>Kategori</th><th>Åtgärd</th></tr>
<tr><td>Exempelrecept</td><td>Middag</td><td>Visa</td></tr>
</table>
</body></html>