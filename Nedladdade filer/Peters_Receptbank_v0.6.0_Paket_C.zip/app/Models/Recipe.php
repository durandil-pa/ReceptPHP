<?php
// Recipe-modell - implementation kommer i nästa steg.
