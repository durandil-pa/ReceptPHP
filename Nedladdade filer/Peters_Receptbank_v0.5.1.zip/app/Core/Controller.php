<?php
abstract class Controller {
 protected function view($file){ include $file; }
}
