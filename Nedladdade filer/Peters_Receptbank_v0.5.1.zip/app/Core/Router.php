<?php
class Router {
 public function dispatch(){ echo 'Router initierad'; }
}
