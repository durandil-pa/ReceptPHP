v0.5.1
- Lade till enkel Router.
- Lade till Controller-bas.
- Lade till LoginController.
- Lade till enkel inloggningsvy.
