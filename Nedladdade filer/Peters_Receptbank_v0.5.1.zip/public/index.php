<?php
require_once __DIR__.'/../bootstrap/app.php';
echo '<h1>'.APP_NAME.' '.APP_VERSION.'</h1>';
