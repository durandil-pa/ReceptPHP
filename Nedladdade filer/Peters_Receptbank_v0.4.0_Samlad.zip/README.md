# Peters Receptbank v0.4.0 (Samlad)

Detta är en samlad projektstruktur baserad på Leverans 1–4.

OBS!
Denna version sammanställer de filer som skapats under våra leveranser.
Nästa version (v0.5.0) kommer att innehålla kompletta, genomtestade filer
som är fullt synkroniserade med varandra.
