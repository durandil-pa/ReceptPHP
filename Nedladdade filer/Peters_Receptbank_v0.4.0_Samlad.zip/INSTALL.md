Installationsöversikt

1. Skapa databasen med SQL-filen från tidigare leveranser.
2. Lägg projektet i webbroten.
3. Anpassa config/config.php.
4. Säkerställ skrivbehörighet till uploads/recipes.
