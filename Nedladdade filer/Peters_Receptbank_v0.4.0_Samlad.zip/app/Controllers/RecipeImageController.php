<?php
class RecipeImageController extends Controller{}
