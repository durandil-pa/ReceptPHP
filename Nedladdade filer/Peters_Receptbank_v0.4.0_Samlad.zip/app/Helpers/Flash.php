<?php
class Flash{}
