<?php
class Ingredient{}
