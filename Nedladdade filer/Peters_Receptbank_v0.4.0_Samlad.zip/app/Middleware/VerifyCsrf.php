<?php
class VerifyCsrf{}
