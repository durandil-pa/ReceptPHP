<?php
abstract class Controller{}
