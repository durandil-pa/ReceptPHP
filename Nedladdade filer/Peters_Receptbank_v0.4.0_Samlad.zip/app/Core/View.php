<?php
class View{}
