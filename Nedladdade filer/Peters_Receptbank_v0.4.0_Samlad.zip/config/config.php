<?php
define('APP_PATH', dirname(__DIR__).'/app');
