# Changelog

## v0.4.0
- Samlad projektstruktur från Leverans 1–4.
- MVC-grund.
- Routing, bootstrap och hjälparklasser.
- Grund för recept-, ingrediens- och bilduppladdning.
