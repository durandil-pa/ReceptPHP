<?php
// Category-modell implementeras i nästa steg.
