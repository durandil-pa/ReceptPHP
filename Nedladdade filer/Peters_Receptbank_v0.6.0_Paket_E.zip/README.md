# Peters Receptbank v0.6.0 - Paket E

Grundstruktur för bilder, kategorier och sökning.
