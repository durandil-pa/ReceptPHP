// Söklogik implementeras senare.
