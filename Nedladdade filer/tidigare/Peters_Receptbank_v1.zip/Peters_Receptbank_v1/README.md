# Peters Receptbank

Version 1.0

Detta är den första projektgrunden.

Innehåller:
- index.php
- config/config.php
- app/Core/Database.php
- katalogstruktur

Nästa leverans:
- Installer
- Router
- Bascontroller
- Första receptmodellen
