<?php
declare(strict_types=1);

define('DB_HOST','localhost');
define('DB_NAME','receptbank');
define('DB_USER','root');
define('DB_PASS','');
define('DB_CHARSET','utf8mb4');

define('SITE_NAME','Peters Receptbank');
define('SITE_VERSION','1.0.0');

define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH', ROOT_PATH.'/app');

date_default_timezone_set('Europe/Stockholm');

if(session_status()===PHP_SESSION_NONE){
    session_name('RECEPTBANK');
    session_start();
}
